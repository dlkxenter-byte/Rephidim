# Rephidim

Application de réservation pour un espace événementiel (300 personnes max,
options vaisselle et traiteur), connectée à Supabase.

## Déployer sur Vercel (sans ligne de commande)

1. Va sur [vercel.com](https://vercel.com) et crée un compte (tu peux te
   connecter avec GitHub).
2. Mets ce dossier sur GitHub :
   - Va sur [github.com/new](https://github.com/new), crée un dépôt (nom
     libre, ex. `rephidim`).
   - Uploade tous les fichiers de ce dossier dans le dépôt (bouton
     "Add file > Upload files" sur la page du dépôt GitHub).
3. Retourne sur Vercel → **Add New... > Project** → choisis le dépôt
   `rephidim` que tu viens de créer → **Deploy**.
4. Après une minute, Vercel te donne une URL du type
   `rephidim-xxxx.vercel.app` — c'est ton application, en ligne, en HTTPS.

## Configuration Supabase

Les identifiants Supabase (URL + clé publique) sont déjà renseignés dans
`components/Rephidim.jsx` (constantes `SUPABASE_URL` et
`SUPABASE_ANON_KEY` en haut du fichier). Si tu changes de projet Supabase
un jour, remplace ces deux valeurs avant de redéployer.

Le script `rephidim-setup.sql` doit avoir été exécuté dans l'éditeur SQL
de ton projet Supabase (Table Editor doit montrer une table
`reservations`). Un compte admin doit exister dans
Authentication > Users pour te connecter à l'espace admin de l'appli.

## Nom de domaine personnalisé (optionnel)

Dans le projet Vercel → **Settings > Domains**, tu peux ajouter ton propre
nom de domaine si tu en as un.
