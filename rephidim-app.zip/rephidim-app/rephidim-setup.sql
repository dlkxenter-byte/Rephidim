-- À exécuter dans Supabase : Project > SQL Editor > New query

-- 1. Table des réservations
create table if not exists reservations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  date date not null,
  slot text not null check (slot in ('matin', 'apres-midi', 'soiree')),
  guests integer not null check (guests > 0 and guests <= 300),
  vaisselle boolean not null default false,
  traiteur boolean not null default false,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  created_at timestamptz not null default now()
);

-- 2. Active la sécurité au niveau des lignes (RLS)
alter table reservations enable row level security;

-- 3. Le public peut UNIQUEMENT créer une réservation (statut "pending" imposé)
--    Il ne peut ni lire, ni modifier, ni supprimer une ligne existante.
create policy "public_insert_pending_only"
on reservations
for insert
to anon
with check (status = 'pending');

-- 4. Seuls les comptes authentifiés (les admins) peuvent lire toutes les réservations
create policy "authenticated_read_all"
on reservations
for select
to authenticated
using (true);

-- 5. Seuls les comptes authentifiés peuvent changer le statut
create policy "authenticated_update_status"
on reservations
for update
to authenticated
using (true)
with check (true);

-- 6. Fonction publique qui expose UNIQUEMENT date / créneau / statut
--    (jamais le nom, l'email ou le nombre d'invités) pour afficher les
--    dates déjà retenues sur la page publique, sans exposer de données
--    personnelles.
create or replace function public_occupied_dates()
returns table(date date, slot text, status text)
language sql
security definer
set search_path = public
as $$
  select date, slot, status
  from reservations
  where status != 'rejected';
$$;

grant execute on function public_occupied_dates() to anon;

-- 7. Créer le compte admin :
--    Dashboard Supabase > Authentication > Users > Add user
--    (email + mot de passe). C'est ce compte qui se connecte dans l'appli.
--    Ne crée PAS de compte admin par SQL : passe par le tableau de bord
--    pour que le mot de passe soit correctement hashé par Supabase Auth.
